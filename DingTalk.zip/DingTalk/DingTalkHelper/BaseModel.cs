﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DingTalk.DingTalkHelper
{
    public class BaseModel
    {
        public int errcode { get; set; }

        public string errmsg { get; set; }
    }
}