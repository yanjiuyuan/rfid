﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DingTalk.DingTalkHelper
{
    public class JsApiTicketModel : BaseModel
    {
        public string ticket { get; set; }
    }
}