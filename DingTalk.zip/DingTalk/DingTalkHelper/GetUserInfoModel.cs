﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DingTalk.DingTalkHelper
{
    public class GetUserInfoModel:BaseModel
    {
        public string userid { get; set; }
    }
}