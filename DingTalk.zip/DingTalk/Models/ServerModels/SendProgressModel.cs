﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DingTalk.Models
{
    public class SendProgressModel
    {
        public long agent_id { get; set; }

        public long task_id { get; set; }
    }
}