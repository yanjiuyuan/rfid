﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DingTalk.Models
{
    public class CommomModel
    {
        public Msg msg { get; set; }
    }

    public class Msg
    {
       public string Id { get; set; }
    }
}