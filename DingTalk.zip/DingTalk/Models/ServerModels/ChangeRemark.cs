﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DingTalk.Models
{
    public class ChangeRemark
    {
        public string Id { get; set; }
        public string Remark { get; set; }
    }
}