﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DingTalk.Models.ServerModels
{
    public class PrintModelCom
    {
        public string TaskId { get; set; }

        public string UserId { get; set; }
    }
}