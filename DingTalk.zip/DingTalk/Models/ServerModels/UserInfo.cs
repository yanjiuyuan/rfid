﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DingTalk.Models.ServerModels
{
    public class UserInfo
    {
        public string applyMan { get; set; }
        public string applyManId { get; set; }
    }
}