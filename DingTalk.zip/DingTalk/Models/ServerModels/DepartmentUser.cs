﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DingTalkServer.Models
{
    public class DepartmentUser
    {
        public string UserId { get; set; }
        public string  Name { get; set; }
    }
}