﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebZhongZhi.Controllers
{
    public class MainController : Controller
    {

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Approval()
        {
            return View();
        }
        public ActionResult Approval_detail()
        {
            return View();
        }
        public ActionResult Approval_detail2()
        {
            return View();
        }
        public ActionResult Approval_purchase()
        {
            return View();
        }
        public ActionResult Approval_list()
        {
            return View();
        }

        public ActionResult Approval_IDone()
        {
            ViewBag.Message = "Your contact page.";
            return View();
        }

        public ActionResult Approval_fromMe()
        {
            return View();
        }

        public ActionResult Approval_copyMe()
        {
            return View();
        }
        public ActionResult Approval_usePublicCar()
        {
            return View();
        }
        public ActionResult Approval_useCar()
        {
            return View();
        }
        public ActionResult Approval_workOvertime()
        {
            return View();
        }
        public ActionResult Approval_officePurchase()
        {
            return View();
        }
        public ActionResult VoteDetail()
        {
            return View();
        }
        public ActionResult Approval_meterieCode()
        {
            return View();
        }
        public ActionResult Approval_officeSupplies()
        {
            return View();
        }
        public ActionResult Approval_sendRead()
        {
            return View();
        }
        public ActionResult VoteList()
        {
            return View();
        }
        public ActionResult Approval_gift()
        {
            return View();
        }
        public ActionResult Approval_picking()
        {
            return View();
        }
        public ActionResult Approval_intoStorage()
        {
            return View();
        }
        public ActionResult Approval_goOut()
        {
            return View();
        }
        public ActionResult Approval_createProject()
        {
            return View();
        }
        public ActionResult Approval_crossHelp()
        {
            return View();
        }
        public ActionResult Approval_techonologySupply()
        {
            return View();
        }
        public ActionResult Approval_changePaper()
        {
            return View();
        }
        public ActionResult Approval_letGoodsGo()
        {
            return View();
        }
        public ActionResult Approval_intellectualProperty()
        {
            return View();
        }
        public ActionResult Approval_borrowThing()
        {
            return View();
        }
        public ActionResult Approval_maintain()
        {
            return View();
        }
        public ActionResult Approval_projectClosure()
        {
            return View();
        }
        public ActionResult Approval_maskSupplies()
        {
            return View();
        }
    }
}