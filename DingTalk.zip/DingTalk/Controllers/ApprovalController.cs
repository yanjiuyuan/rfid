﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebZhongZhi.Controllers
{
    public class ApprovalController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult OfficeSupplies()
        {
            return View();
        }
        public ActionResult OfficePurchase()
        {
            return View();
        }
        public ActionResult UploadPic()
        {
            return View();
        }
        public ActionResult UseCar()
        {
            return View();
        }
        public ActionResult UsePublicCar()
        {
            return View();
        }
        public ActionResult CarManager()
        {
            return View();
        }
        public ActionResult Purchase()
        {
            return View();
        }
        public ActionResult AddMaterielCode()
        {
            return View();
        }
        public ActionResult FileManager()
        {
            return View();
        }
        public ActionResult ProjectManager()
        {
            return View();
        }
        public ActionResult AddProject()
        {
            return View();
        }
        public ActionResult WorkOvertime()
        {
            return View();
        }
        public ActionResult UploadPaper()
        {
            return View();
        }
        public ActionResult UploadPaperRe()
        {
            return View();
        }
        public ActionResult DownloadPaper()
        {
            return View();
        }
        public ActionResult SendRead()
        {
            return View();
        }
        public ActionResult PublishNew()
        {
            return View();
        }
        public ActionResult PublishProduct()
        {
            return View();
        }
        public ActionResult PublishRecruit()
        {
            return View();
        }
        public ActionResult Vote()
        {
            return View();
        }
        public ActionResult Gift()
        {
            return View();
        }
        public ActionResult Picking()
        {
            return View();
        }
        public ActionResult IntoStorage()
        {
            return View();
        }
        public ActionResult GoOut()
        {
            return View();
        }
        public ActionResult CreateProject()
        {
            return View();
        }
        public ActionResult CrossHelp()
        {
            return View();
        }
        public ActionResult TechonologySupply()
        {
            return View();
        }
        public ActionResult ChangePaper()
        {
            return View();
        }
        public ActionResult LetGoodsGo()
        {
            return View();
        }
        public ActionResult IntellectualProperty()
        {
            return View();
        }
        public ActionResult PickingManager()
        {
            return View();
        }
        public ActionResult BorrowThing()
        {
            return View();
        }
        public ActionResult Maintain()
        {
            return View();
        }
        public ActionResult ProjectClosure()
        {
            return View();
        }
        public ActionResult ProduceRate()
        {
            return View();
        }
        public ActionResult FlowEdit()
        {
            return View();
        }
        public ActionResult RoleEdit()
        {
            return View();
        }
        public ActionResult logManager()
        {
            return View();
        }
        public ActionResult up()
        {
            return View();
        }
        public ActionResult up2()
        {
            return View();
        }
        public ActionResult MaskSupplies()
        {
            return View();
        }
        public ActionResult MaskQuery()
        {
            return View();
        }
        public ActionResult PublicAreaManager()
        {
            return View();
        }
    }
}