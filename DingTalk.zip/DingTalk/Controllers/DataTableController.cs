﻿
using DingTalk.EF;
using DingTalk.Models;
using DingTalk.Models.DingModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace DingTalk.Controllers
{
    /// <summary>
    /// 数据库表操作
    /// </summary>
    [RoutePrefix("DataTable")]
    public class DataTableController : ApiController
    {

    }
}
