﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebZhongZhi.Controllers
{
    public class ShowDetailController : Controller
    {
        // GET: ShowDetail
        public ActionResult Index()
        {
            return View();
        }
    }
}